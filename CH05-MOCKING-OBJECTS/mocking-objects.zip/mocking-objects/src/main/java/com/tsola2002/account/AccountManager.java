package com.tsola2002.account;

public interface AccountManager {

  Account findAccountForUser(String userId);

  void updateAccount(Account account);

}
