package com.tsola2002.account;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

public class AccountServiceTestMockito {

  // this will create a mock object through an annotation
  @Mock
  private AccountManager mockAccountManager;

  @Test
  public void testTransferOk() {

    // setup 2 accounts betweeen which money will be transferred
    Account senderAccount = new Account( "1", 200 );
    Account beneficiaryAccount = new Account( "2", 100 );

    // we declare expectations using the when method
    // lenient method modifies strictness of object mocking
    Mockito.lenient()
        .when(mockAccountManager.findAccountForUser("1"))
        .thenReturn(senderAccount);

    // we declare expectations using the when method
    // lenient method modifies strictness of object mocking
    Mockito.lenient()
        .when(mockAccountManager.findAccountForUser("2"))
        .thenReturn(beneficiaryAccount);

    AccountService accountService = new AccountService();
    accountService.setAccountManager(mockAccountManager);
    accountService.transfer( "1", "2", 50 );


    assertEquals( 150, senderAccount.getBalance() );
    assertEquals( 150, beneficiaryAccount.getBalance() );
    
  }

}
